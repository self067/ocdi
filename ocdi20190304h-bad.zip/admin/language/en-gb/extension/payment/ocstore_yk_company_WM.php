<?php
$_['heading_title'] = 'Яндекс.Касса (Webmoney)';
?>